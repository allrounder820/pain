package com.example.layout;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Navigation to respective activities
        findViewById(R.id.btnLinear).setOnClickListener(v -> startActivity(new Intent(this, LinearActivity.class)));
        findViewById(R.id.btnRelative).setOnClickListener(v -> startActivity(new Intent(this, RelativeActivity.class)));
        findViewById(R.id.btnTable).setOnClickListener(v -> startActivity(new Intent(this, TableActivity.class)));
        findViewById(R.id.btnFrame).setOnClickListener(v -> startActivity(new Intent(this, FrameActivity.class)));
        findViewById(R.id.btnAbsolute).setOnClickListener(v -> startActivity(new Intent(this, AbsoluteActivity.class)));
        findViewById(R.id.btnListView).setOnClickListener(v -> startActivity(new Intent(this, ListViewActivity.class)));
        findViewById(R.id.btnGridView).setOnClickListener(v -> startActivity(new Intent(this, GridViewActivity.class)));
    }
}
